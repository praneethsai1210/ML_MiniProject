"""
========================================================================================
Project: Predicting Diabetes Disease Progression Using Regression Techniques
Academic Mini Project - Machine Learning (Course Code: 25CSA201)
Institution: MNR University
Department: Computer Science and Engineering
Academic Year: 2026-2027 | Year / Sem: II / I

Team Members:
1. Syed Sajid              (Roll No: 25RBCSE0001) - B.Tech (Hons.) CSE
2. Pilla Praneeth Sai      (Roll No: 25RBAID0015) - B.Tech (Hons.) CSE-AIDS
3. Md. Jaffar Pasha        (Roll No: 25RBAID0025) - B.Tech (Hons.) CSE-AIDS
4. Nevuluri Manoj Kumar    (Roll No: 25RBAIM0083) - B.Tech (Hons.) CSE-AIML

Project Guide: Dr. M Praveen Sir – Asst. Prof.
========================================================================================
Description:
A comprehensive study comparing Simple, Multiple, Polynomial, Ridge, Lasso, Elastic Net,
Random Forest, Gradient Boosting, and a from-scratch Gradient Descent optimizer on the
clinical Diabetes benchmark dataset (442 patients, 10 physiological features).
========================================================================================
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for automated execution and report image generation
import matplotlib.pyplot as plt
from scipy import stats

from sklearn.datasets import load_diabetes
from sklearn.model_selection import (
    train_test_split, KFold, cross_val_score, RepeatedKFold, GridSearchCV
)
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import (
    LinearRegression, Ridge, Lasso, RidgeCV, LassoCV, ElasticNetCV, SGDRegressor
)
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# --------------------------------------------------------------------------------------
# 0. Global Setup & Directory Management
# --------------------------------------------------------------------------------------
FIG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(FIG_DIR, exist_ok=True)
RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)

def print_header(title):
    print("\n" + "=" * 80)
    print(f" {title}")
    print("=" * 80)

def print_subheader(title):
    print("\n--- " + title + " ---")


# --------------------------------------------------------------------------------------
# 1. Dataset Loading & Exploratory Data Analysis (EDA)
# --------------------------------------------------------------------------------------
def load_and_explore_data():
    print_header("1. DATASET LOADING & EXPLORATORY DATA ANALYSIS")
    
    # Load dataset with scaled=False to inspect original physiological units
    raw_data = load_diabetes(as_frame=True, scaled=False)
    X = raw_data.data
    y = raw_data.target
    
    print(f"Dataset Shape: {X.shape[0]} patients, {X.shape[1]} baseline features")
    print(f"Total Missing Values: {X.isnull().sum().sum()}")
    
    # Target distribution statistics
    target_mean = y.mean()
    target_std = y.std()
    target_min = y.min()
    target_median = y.median()
    target_max = y.max()
    target_skew = y.skew()
    
    print_subheader("Target Variable (Disease Progression Score) Summary")
    print(f"Mean: {target_mean:.2f} | Std Dev: {target_std:.2f}")
    print(f"Min: {target_min:.1f} | Median: {target_median:.1f} | Max: {target_max:.1f}")
    print(f"Skewness: {target_skew:.2f} (slightly right-skewed)")
    
    # Descriptive statistics table
    stats_df = pd.DataFrame({
        "Mean": X.mean(),
        "Std": X.std(),
        "Min": X.min(),
        "25%": X.quantile(0.25),
        "Median": X.median(),
        "75%": X.quantile(0.75),
        "Max": X.max()
    })
    print_subheader("Feature Summary Statistics (Original Physiological Units)")
    print(stats_df.round(2).to_string())
    
    # Pearson Correlation with target
    df_all = pd.concat([X, y.rename("progression")], axis=1)
    correlations = df_all.corr()["progression"].drop("progression").sort_values(ascending=False)
    print_subheader("Pearson Correlation with Disease Progression")
    print(correlations.round(3).to_string())
    
    # Figure 3: Distribution of target variable
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
    ax1.hist(y, bins=25, color="#2b5c8f", edgecolor="white", alpha=0.85)
    ax1.axvline(target_mean, color="#d95f02", linestyle="--", linewidth=1.8, label=f"mean = {target_mean:.1f}")
    ax1.set_xlabel("Disease progression score")
    ax1.set_ylabel("Patients")
    ax1.set_title("Distribution of target")
    ax1.legend()
    
    ax2.boxplot(y, vert=False, patch_artist=True, boxprops=dict(facecolor="#d0e1f9", color="#2b5c8f"))
    ax2.set_xlabel("Disease progression score")
    ax2.set_title("Box plot")
    ax2.set_yticks([])
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig03_target_distribution.png"), dpi=300)
    plt.close()
    
    # Figure 4: Histograms of the 10 input features
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    axes = axes.flatten()
    for idx, col in enumerate(X.columns):
        axes[idx].hist(X[col], bins=20, color="#386cb0", edgecolor="white", alpha=0.85)
        axes[idx].set_title(col, fontsize=11, fontweight="bold")
        axes[idx].tick_params(labelsize=9)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig04_feature_histograms.png"), dpi=300)
    plt.close()
    
    # Figure 5: Feature vs target scatter plots with fitted trendline
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    axes = axes.flatten()
    for idx, col in enumerate(X.columns):
        r_val = correlations[col]
        axes[idx].scatter(X[col], y, alpha=0.45, s=15, color="#1f78b4")
        m, b = np.polyfit(X[col], y, 1)
        xseq = np.linspace(X[col].min(), X[col].max(), 100)
        axes[idx].plot(xseq, m * xseq + b, color="#e31a1c", linewidth=1.5)
        axes[idx].set_title(f"{col} (r = {r_val:+.2f})", fontsize=10)
        axes[idx].tick_params(labelsize=8)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig05_feature_scatter_fitted_lines.png"), dpi=300)
    plt.close()
    
    # Figure 6: Correlation matrix of all features and target
    fig, ax = plt.subplots(figsize=(8, 7))
    cax = ax.matshow(df_all.corr(), cmap="coolwarm", vmin=-1, vmax=1)
    fig.colorbar(cax, shrink=0.8)
    ax.set_xticks(range(len(df_all.columns)))
    ax.set_yticks(range(len(df_all.columns)))
    ax.set_xticklabels(df_all.columns, rotation=45, ha="left", fontsize=9)
    ax.set_yticklabels(df_all.columns, fontsize=9)
    for i in range(len(df_all.columns)):
        for j in range(len(df_all.columns)):
            val = df_all.corr().iloc[i, j]
            color = "white" if abs(val) > 0.55 else "black"
            ax.text(j, i, f"{val:.2f}", ha="center", va="center", color=color, fontsize=7.5)
    plt.title("Correlation Matrix of Features and Target", pad=20, fontweight="bold")
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig06_correlation_matrix.png"), dpi=300)
    plt.close()
    
    return X, y


# --------------------------------------------------------------------------------------
# 2. Train-Test Split & Multicollinearity Analysis (VIF)
# --------------------------------------------------------------------------------------
def split_data_and_check_vif(X, y):
    print_header("2. TRAIN-TEST SPLIT & MULTICOLLINEARITY (VIF)")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )
    print(f"Total Records: {len(X)}")
    print(f"Training Set : {len(X_train)} samples (80%)")
    print(f"Test Set     : {len(X_test)} samples (20%)")
    print(f"Training Target Mean: {y_train.mean():.1f} | Test Target Mean: {y_test.mean():.1f}")
    
    # Compute Variance Inflation Factor (VIF) on standardized training features
    scaler = StandardScaler()
    X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X.columns)
    
    vif_data = []
    for col in X.columns:
        other_cols = [c for c in X.columns if c != col]
        lr = LinearRegression().fit(X_train_scaled[other_cols], X_train_scaled[col])
        r2 = r2_score(X_train_scaled[col], lr.predict(X_train_scaled[other_cols]))
        vif = 1.0 / (1.0 - r2) if (1.0 - r2) > 1e-10 else 999.0
        verdict = "Serious" if vif > 10 else ("Warning" if vif > 5 else "Acceptable")
        vif_data.append({"Feature": col, "VIF": round(vif, 1), "Verdict": verdict})
        
    vif_df = pd.DataFrame(vif_data)
    print_subheader("Variance Inflation Factors (Training Data)")
    print(vif_df.to_string(index=False))
    
    return X_train, X_test, y_train, y_test


# --------------------------------------------------------------------------------------
# 3. Model Training & Evaluation (The 7 Course Models + Polynomial Ridge)
# --------------------------------------------------------------------------------------
def evaluate_course_models(X_train, X_test, y_train, y_test):
    print_header("3. MODEL TRAINING & COMPARISON (COURSE MODELS)")
    
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    
    def evaluate(name, model, Xtr, Xte):
        model.fit(Xtr, y_train)
        pred = model.predict(Xte)
        cv = cross_val_score(model, Xtr, y_train, cv=kf, scoring="r2")
        mse = mean_squared_error(y_test, pred)
        return {
            "Model": name,
            "Train R2": r2_score(y_train, model.predict(Xtr)),
            "Test MAE": mean_absolute_error(y_test, pred),
            "Test MSE": mse,
            "Test RMSE": np.sqrt(mse),
            "Test R2": r2_score(y_test, pred),
            "CV R2 (mean)": cv.mean(),
            "CV R2 (std)": cv.std()
        }

    def scaled(*steps):
        return make_pipeline(StandardScaler(), *steps)

    rows = []
    
    # 1. Simple Linear Regression (BMI only)
    simple_lr = LinearRegression()
    rows.append(evaluate("Simple LR (BMI only)", simple_lr, X_train[["bmi"]], X_test[["bmi"]]))
    
    # Inspect Simple LR equation
    simple_lr.fit(X_train[["bmi"]], y_train)
    b0 = simple_lr.intercept_
    b1 = simple_lr.coef_[0]
    print(f"\nSimple Linear Regression Equation: progression = {b0:.2f} + {b1:.2f} * BMI")
    
    # Figure 7: Simple Linear Regression Plot
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.scatter(X_train["bmi"], y_train, color="#1f78b4", alpha=0.5, s=20, label="Train")
    ax.scatter(X_test["bmi"], y_test, color="#33a02c", alpha=0.7, s=25, label="Test")
    bmi_min = min(X_train["bmi"].min(), X_test["bmi"].min())
    bmi_max = max(X_train["bmi"].max(), X_test["bmi"].max())
    bmi_seq = np.linspace(bmi_min, bmi_max, 100)
    ax.plot(bmi_seq, b0 + b1 * bmi_seq, color="#ff7f00", linewidth=2.0, label="Fitted line")
    ax.set_xlabel("BMI")
    ax.set_ylabel("Progression")
    ax.set_title("Simple Linear Regression using BMI only")
    ax.legend()
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig07_simple_lr_bmi.png"), dpi=300)
    plt.close()
    
    # 2. Multiple Linear Regression
    rows.append(evaluate("Multiple LR", scaled(LinearRegression()), X_train, X_test))
    
    # 3. Polynomial Regression (Degrees 2 and 3)
    for deg in [2, 3]:
        rows.append(evaluate(
            f"Polynomial (deg {deg}) LR",
            scaled(PolynomialFeatures(deg, include_bias=False), LinearRegression()),
            X_train, X_test
        ))
        
    # 4. Polynomial (deg 2) + Ridge (alpha=100)
    rows.append(evaluate(
        "Polynomial (deg 2) + Ridge",
        scaled(PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=100)),
        X_train, X_test
    ))
    
    # 5. Ridge Regression (alpha=10)
    rows.append(evaluate("Ridge (alpha=10)", scaled(Ridge(alpha=10)), X_train, X_test))
    
    # 6. Lasso Regression (alpha=1)
    rows.append(evaluate("Lasso (alpha=1)", scaled(Lasso(alpha=1)), X_train, X_test))
    
    # 7. Random Forest Regressor (baseline: 100 trees)
    rows.append(evaluate(
        "Random Forest",
        RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE),
        X_train, X_test
    ))
    
    results_df = pd.DataFrame(rows)
    print_subheader("Table 9: Performance of Course Regression Models")
    print(results_df.round(4).to_string(index=False))
    
    # Figure 10: Model Comparison Bar Chart (omitting deg 3 LR because it is off scale)
    plot_df = results_df[~results_df["Model"].str.contains("deg 3")].copy()
    x_indices = np.arange(len(plot_df))
    width = 0.25
    
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(x_indices - width, plot_df["Train R2"], width, label="Train R²", color="#4393c3")
    ax.bar(x_indices, plot_df["CV R2 (mean)"], width, label="CV R²", color="#2166ac")
    ax.bar(x_indices + width, plot_df["Test R2"], width, label="Test R²", color="#f4a582")
    
    ax.set_ylabel("R²")
    ax.set_title("Model comparison (degree-3 polynomial omitted: off the scale)")
    ax.set_xticks(x_indices)
    ax.set_xticklabels(plot_df["Model"], rotation=15, ha="right", fontsize=9)
    ax.legend()
    ax.set_ylim(-0.05, 1.0)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig10_model_comparison_r2.png"), dpi=300)
    plt.close()
    
    return results_df


# --------------------------------------------------------------------------------------
# Conceptual Figures: L1/L2 Geometry (Fig 8) & Bias-Variance Curves (Fig 9)
# --------------------------------------------------------------------------------------
def generate_conceptual_figures():
    # Figure 8: L1 (Lasso) vs L2 (Ridge) Geometric Contours
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 4.5))
    
    # Grid for contours
    b1 = np.linspace(-3, 3, 400)
    b2 = np.linspace(-3, 3, 400)
    B1, B2 = np.meshgrid(b1, b2)
    # Elliptical error contours centered at (1.2, 1.2)
    Z = 1.5 * (B1 - 1.2)**2 + 1.0 * (B2 - 1.2)**2 + 0.8 * (B1 - 1.2) * (B2 - 1.2)
    
    # Lasso: Diamond |b1| + |b2| <= 1.2
    ax1.contour(B1, B2, Z, levels=[0.2, 0.6, 1.2, 2.0, 3.2], cmap="viridis")
    diamond_x = [0, 1.2, 0, -1.2, 0]
    diamond_y = [1.2, 0, -1.2, 0, 1.2]
    ax1.plot(diamond_x, diamond_y, color="#2b5c8f", linewidth=2)
    ax1.fill(diamond_x, diamond_y, color="#d0e1f9", alpha=0.5)
    ax1.axhline(0, color="gray", linewidth=0.8)
    ax1.axvline(0, color="gray", linewidth=0.8)
    ax1.plot(0, 1.2, "ro", markersize=6)
    ax1.text(0.1, 1.25, "Corner (β1=0)", color="#e31a1c", fontweight="bold", fontsize=9)
    ax1.set_xlabel("β1")
    ax1.set_ylabel("β2")
    ax1.set_title("Lasso (L1)", fontsize=11, fontweight="bold")
    ax1.set_xlim(-2.5, 2.5)
    ax1.set_ylim(-2.5, 2.5)
    ax1.grid(True, linestyle="--", alpha=0.3)
    
    # Ridge: Circle b1^2 + b2^2 <= 1.2^2
    ax2.contour(B1, B2, Z, levels=[0.2, 0.6, 1.2, 2.0, 3.2], cmap="viridis")
    theta = np.linspace(0, 2*np.pi, 200)
    ax2.plot(1.2 * np.cos(theta), 1.2 * np.sin(theta), color="#2b5c8f", linewidth=2)
    ax2.fill(1.2 * np.cos(theta), 1.2 * np.sin(theta), color="#d0e1f9", alpha=0.5)
    ax2.axhline(0, color="gray", linewidth=0.8)
    ax2.axvline(0, color="gray", linewidth=0.8)
    # Tangent contact point
    ax2.plot(0.7, 0.98, "ro", markersize=6)
    ax2.text(0.8, 1.05, "Contact (β1≠0, β2≠0)", color="#e31a1c", fontweight="bold", fontsize=9)
    ax2.set_xlabel("β1")
    ax2.set_ylabel("β2")
    ax2.set_title("Ridge (L2)", fontsize=11, fontweight="bold")
    ax2.set_xlim(-2.5, 2.5)
    ax2.set_ylim(-2.5, 2.5)
    ax2.grid(True, linestyle="--", alpha=0.3)
    
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig08_l1_vs_l2_constraint.png"), dpi=300)
    plt.close()
    
    # Figure 9: Underfitting, Good fit, Overfitting polynomial curves
    np.random.seed(0)
    x_syn = np.sort(np.random.rand(30))
    y_syn = np.cos(1.5 * np.pi * x_syn) + np.random.randn(30) * 0.1
    x_plot = np.linspace(0, 1, 200)
    
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.5))
    titles = ["Underfitting (degree 1)", "Good fit (degree 4)", "Overfitting (degree 15)"]
    deg_list = [1, 4, 15]
    
    for ax, deg, title in zip(axes, deg_list, titles):
        poly_m = make_pipeline(PolynomialFeatures(deg), LinearRegression()).fit(x_syn[:, np.newaxis], y_syn)
        ax.plot(x_plot, np.cos(1.5 * np.pi * x_plot), "--", color="black", label="True pattern", alpha=0.7)
        ax.plot(x_plot, poly_m.predict(x_plot[:, np.newaxis]), color="#ff7f00", linewidth=1.8, label="Model")
        ax.scatter(x_syn, y_syn, edgecolor="b", color="none", s=20, label="Samples")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_xlim(0, 1)
        ax.set_ylim(-1.6, 1.6)
        ax.set_title(title, fontsize=10, fontweight="bold")
        if deg == 1:
            ax.legend(loc="best", fontsize=8)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig09_polynomial_tradeoff.png"), dpi=300)
    plt.close()


# --------------------------------------------------------------------------------------
# 4. Overfitting Study & Polynomial Complexity Analysis
# --------------------------------------------------------------------------------------
def analyze_polynomial_degrees(X_train, X_test, y_train, y_test):
    print_header("4. POLYNOMIAL DEGREE COMPLEXITY & OVERFITTING ANALYSIS")
    
    poly_records = []
    for deg in range(1, 5):
        poly_pipe = make_pipeline(
            StandardScaler(),
            PolynomialFeatures(deg, include_bias=False),
            LinearRegression()
        )
        poly_pipe.fit(X_train, y_train)
        
        train_r2 = r2_score(y_train, poly_pipe.predict(X_train))
        test_r2 = r2_score(y_test, poly_pipe.predict(X_test))
        
        # Count created features
        n_features = poly_pipe.named_steps["polynomialfeatures"].n_output_features_
        diagnosis = (
            "Good fit, small gap" if deg == 1
            else ("Training rises, test falls: starting to overfit" if deg == 2
                  else ("Severe overfitting" if deg == 3 else "Memorizes training set completely"))
        )
        poly_records.append({
            "Degree": deg,
            "Features": n_features,
            "Train R2": round(train_r2, 3),
            "Test R2": round(test_r2, 3),
            "Diagnosis": diagnosis
        })
        
    poly_df = pd.DataFrame(poly_records)
    print_subheader("Table 10: Effect of Polynomial Degree on Train and Test R²")
    print(poly_df.to_string(index=False))
    
    # Figure 11: Training and Test R2 vs Degree
    degrees = [p["Degree"] for p in poly_records]
    train_r2s = [p["Train R2"] for p in poly_records]
    # Clip test R2 for visualization clarity as in report
    test_r2_clipped = [max(p["Test R2"], -1.0) for p in poly_records]
    
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(degrees[:3], train_r2s[:3], "o-", color="#2b5c8f", label="Train R²")
    ax.plot(degrees[:3], test_r2_clipped[:3], "s-", color="#d95f02", label="Test R² (clipped at -1)")
    ax.set_xlabel("Polynomial degree")
    ax.set_ylabel("R²")
    ax.set_title("Training vs test R² as complexity grows (degree 3 test R² = -14.28)")
    ax.set_xticks([1, 2, 3])
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend()
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig11_polynomial_degree_overfitting.png"), dpi=300)
    plt.close()
    
    return poly_df


# --------------------------------------------------------------------------------------
# 5. Regularization Analysis & Hyperparameter Tuning (RidgeCV, LassoCV, ElasticNetCV)
# --------------------------------------------------------------------------------------
def tune_regularization_and_compare_coefficients(X_train, X_test, y_train, y_test):
    print_header("5. REGULARIZATION TUNING & COEFFICIENT BEHAVIOR")
    
    def scaled(*steps):
        return make_pipeline(StandardScaler(), *steps)

    # 1. Tuning Ridge via RidgeCV
    ridge_alphas = np.logspace(-2, 3, 30)
    ridge_cv = scaled(RidgeCV(alphas=ridge_alphas, cv=5)).fit(X_train, y_train)
    best_ridge_alpha = ridge_cv[-1].alpha_
    
    # 2. Tuning Lasso via LassoCV
    lasso_alphas = np.logspace(-2, 1.5, 40)
    lasso_cv = scaled(LassoCV(alphas=lasso_alphas, cv=5, random_state=RANDOM_STATE, max_iter=10000)).fit(X_train, y_train)
    best_lasso_alpha = lasso_cv[-1].alpha_
    
    print(f"Optimal Ridge alpha : {best_ridge_alpha:.2f}")
    print(f"Optimal Lasso alpha : {best_lasso_alpha:.2f}")
    
    # Coefficients on standardized features
    scaler = StandardScaler().fit(X_train)
    Xs = scaler.transform(X_train)
    
    lr_fit = LinearRegression().fit(Xs, y_train)
    r10_fit = Ridge(alpha=10).fit(Xs, y_train)
    l1_fit = Lasso(alpha=1).fit(Xs, y_train)
    rcv_fit = Ridge(alpha=best_ridge_alpha).fit(Xs, y_train)
    lcv_fit = Lasso(alpha=best_lasso_alpha).fit(Xs, y_train)
    
    coef_df = pd.DataFrame({
        "Linear": lr_fit.coef_,
        "Ridge (α=10)": r10_fit.coef_,
        "Lasso (α=1)": l1_fit.coef_,
        f"RidgeCV (α≈{best_ridge_alpha:.1f})": rcv_fit.coef_,
        f"LassoCV (α≈{best_lasso_alpha:.2f})": lcv_fit.coef_
    }, index=X_train.columns)
    
    print_subheader("Table 11: Feature Coefficients on Standardized Features")
    print(coef_df.round(2).to_string())
    
    # Figure 12: Coefficients Comparison Bar Chart
    fig, ax = plt.subplots(figsize=(9, 4.5))
    x_pos = np.arange(len(coef_df))
    width = 0.25
    ax.bar(x_pos - width, coef_df["Linear"], width, label="Linear", color="#4393c3")
    ax.bar(x_pos, coef_df["Ridge (α=10)"], width, label="Ridge (α=10)", color="#2166ac")
    ax.bar(x_pos + width, coef_df["Lasso (α=1)"], width, label="Lasso (α=1)", color="#d95f02")
    ax.set_xticks(x_pos)
    ax.set_xticklabels(coef_df.index, fontsize=9)
    ax.set_ylabel("Coefficient (standardized)")
    ax.set_title("Coefficients of Linear, Ridge and Lasso regression compared")
    ax.axhline(0, color="gray", linestyle="--", linewidth=0.8)
    ax.legend()
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig12_coefficients_comparison.png"), dpi=300)
    plt.close()
    
    # Figure 13: Regularization Paths
    alphas_ridge = np.logspace(-2, 4, 100)
    alphas_lasso = np.logspace(-2, 1.5, 100)
    
    ridge_paths = [Ridge(alpha=a).fit(Xs, y_train).coef_ for a in alphas_ridge]
    lasso_paths = [Lasso(alpha=a, max_iter=5000).fit(Xs, y_train).coef_ for a in alphas_lasso]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    ax1.plot(alphas_ridge, ridge_paths)
    ax1.set_xscale("log")
    ax1.set_xlabel("alpha")
    ax1.set_ylabel("Coefficient")
    ax1.set_title("Ridge path")
    ax1.grid(True, linestyle="--", alpha=0.4)
    
    ax2.plot(alphas_lasso, lasso_paths)
    ax2.set_xscale("log")
    ax2.set_xlabel("alpha")
    ax2.set_ylabel("Coefficient")
    ax2.set_title("Lasso path")
    ax2.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig13_regularization_paths.png"), dpi=300)
    plt.close()
    
    # Figure 14: Cross-validated MSE as a function of alpha
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    
    # Manual 5-fold CV MSE across alphas for plotting
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    r_mses = [-cross_val_score(Ridge(alpha=a), Xs, y_train, cv=kf, scoring="neg_mean_squared_error").mean() for a in ridge_alphas]
    l_mses = [-cross_val_score(Lasso(alpha=a, max_iter=5000), Xs, y_train, cv=kf, scoring="neg_mean_squared_error").mean() for a in lasso_alphas]
    
    ax1.plot(ridge_alphas, r_mses, color="#2166ac")
    ax1.axvline(best_ridge_alpha, linestyle="--", color="#d95f02", label=f"best ≈ {best_ridge_alpha:.1f}")
    ax1.set_xscale("log")
    ax1.set_xlabel("alpha")
    ax1.set_ylabel("CV MSE")
    ax1.set_title("RidgeCV")
    ax1.legend()
    
    ax2.plot(lasso_alphas, l_mses, color="#2166ac")
    ax2.axvline(best_lasso_alpha, linestyle="--", color="#d95f02", label=f"best ≈ {best_lasso_alpha:.2f}")
    ax2.set_xscale("log")
    ax2.set_xlabel("alpha")
    ax2.set_ylabel("CV MSE")
    ax2.set_title("LassoCV")
    ax2.legend()
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig14_cv_mse_vs_alpha.png"), dpi=300)
    plt.close()
    
    # Table 12: Degree-2 Polynomial with Different Ridge Strengths
    poly2_ridge_alphas = [1, 10, 30, 100, 300, 1000]
    p2_records = []
    for a in poly2_ridge_alphas:
        pipe = make_pipeline(
            StandardScaler(),
            PolynomialFeatures(2, include_bias=False),
            StandardScaler(),
            Ridge(alpha=a)
        )
        pipe.fit(X_train, y_train)
        cv = cross_val_score(pipe, X_train, y_train, cv=kf, scoring="r2")
        p2_records.append({
            "alpha": a,
            "Train R2": round(r2_score(y_train, pipe.predict(X_train)), 3),
            "Test R2": round(r2_score(y_test, pipe.predict(X_test)), 3),
            "CV R2": round(cv.mean(), 3)
        })
    print_subheader("Table 12: Degree-2 Polynomial with Different Ridge Strengths")
    print(pd.DataFrame(p2_records).to_string(index=False))
    
    return best_ridge_alpha, best_lasso_alpha, lasso_cv


# --------------------------------------------------------------------------------------
# 6. Ensemble Models & Hyperparameter Tuning (GridSearch)
# --------------------------------------------------------------------------------------
def tune_ensembles_and_compare(X_train, X_test, y_train, y_test, best_lasso_alpha):
    print_header("6. ENSEMBLE MODELS & HYPERPARAMETER TUNING")
    
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    def scaled(*steps): return make_pipeline(StandardScaler(), *steps)

    # Elastic Net
    enet_cv = scaled(ElasticNetCV(
        l1_ratio=[.1, .3, .5, .7, .9, 1],
        alphas=np.logspace(-2, 1.5, 40),
        cv=5,
        random_state=RANDOM_STATE,
        max_iter=10000
    )).fit(X_train, y_train)
    
    # Gradient Boosting Grid Search
    gb_gs = GridSearchCV(
        GradientBoostingRegressor(random_state=RANDOM_STATE),
        {
            "n_estimators": [50, 100, 200],
            "learning_rate": [0.01, 0.05, 0.1],
            "max_depth": [1, 2, 3]
        },
        cv=kf,
        scoring="r2"
    ).fit(X_train, y_train)
    
    # Random Forest Grid Search
    rf_gs = GridSearchCV(
        RandomForestRegressor(random_state=RANDOM_STATE),
        {
            "n_estimators": [100, 300],
            "max_depth": [3, 5, 8, None],
            "min_samples_leaf": [1, 5, 10]
        },
        cv=kf,
        scoring="r2"
    ).fit(X_train, y_train)
    
    print(f"Optimal ElasticNet: alpha={enet_cv[-1].alpha_:.3f}, l1_ratio={enet_cv[-1].l1_ratio_}")
    print(f"Optimal Gradient Boosting: {gb_gs.best_params_}")
    print(f"Optimal Random Forest    : {rf_gs.best_params_}")
    
    # Evaluate configurations for Table 14
    models_to_compare = [
        ("Lasso (CV alpha)", scaled(Lasso(alpha=best_lasso_alpha))),
        ("Random Forest (default)", RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE)),
        ("Random Forest (tuned)", RandomForestRegressor(**rf_gs.best_params_, random_state=RANDOM_STATE)),
        ("Gradient Boosting (default depth 2)", GradientBoostingRegressor(max_depth=2, random_state=RANDOM_STATE)),
        ("Gradient Boosting (tuned)", GradientBoostingRegressor(**gb_gs.best_params_, random_state=RANDOM_STATE)),
        ("Elastic Net (CV)", enet_cv)
    ]
    
    table14_rows = []
    for name, mdl in models_to_compare:
        mdl.fit(X_train, y_train)
        pred = mdl.predict(X_test)
        mse = mean_squared_error(y_test, pred)
        cv = cross_val_score(mdl, X_train, y_train, cv=kf, scoring="r2")
        table14_rows.append({
            "Model": name,
            "Train R2": round(r2_score(y_train, mdl.predict(X_train)), 3) if name != "Elastic Net (CV)" else "—",
            "Test MAE": round(mean_absolute_error(y_test, pred), 2),
            "Test RMSE": round(np.sqrt(mse), 2),
            "Test R2": round(r2_score(y_test, pred), 3),
            "CV R2": round(cv.mean(), 3)
        })
        
    print_subheader("Table 14: Tuned Ensembles Compared with the Linear Models")
    print(pd.DataFrame(table14_rows).to_string(index=False))


# --------------------------------------------------------------------------------------
# 7. Feature Importance Analysis
# --------------------------------------------------------------------------------------
def analyze_feature_importance(X_train, X_test, y_train, y_test, lasso_cv):
    print_header("7. MULTI-METHOD FEATURE IMPORTANCE ANALYSIS")
    
    # 1. Random Forest MDI importance
    rf = RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE)
    rf.fit(X_train, y_train)
    rf_imp = pd.Series(rf.feature_importances_, index=X_train.columns).sort_values(ascending=False)
    
    # 2. Permutation Importance on LassoCV model
    perm_imp = permutation_importance(lasso_cv, X_test, y_test, n_repeats=30, random_state=RANDOM_STATE, scoring="r2")
    perm_mean = pd.Series(perm_imp.importances_mean, index=X_train.columns)
    perm_std = pd.Series(perm_imp.importances_std, index=X_train.columns)
    
    fi_table = pd.DataFrame({
        "RF importance": rf_imp,
        "Permutation importance": [f"{perm_mean[c]:.3f} ± {perm_std[c]:.3f}" for c in rf_imp.index]
    })
    print_subheader("Table 13: Random Forest and Permutation Importance of Lasso Model")
    print(fi_table.to_string())
    
    # Figure 15: Feature Importance Horizontal Bar Plots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    y_pos = np.arange(len(rf_imp))
    ax1.barh(y_pos, rf_imp.values[::-1], color="#2b5c8f", align="center")
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(rf_imp.index[::-1], fontsize=9)
    ax1.set_xlabel("Importance")
    ax1.set_title("Random Forest importance")
    
    # Order permutation importance matching RF order
    perm_plot_order = rf_imp.index[::-1]
    ax2.barh(y_pos, perm_mean[perm_plot_order], color="#33a02c", align="center")
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels(perm_plot_order, fontsize=9)
    ax2.set_xlabel("Drop in R²")
    ax2.set_title("Permutation importance (Lasso, test set)")
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig15_feature_importance.png"), dpi=300)
    plt.close()


# --------------------------------------------------------------------------------------
# 8. Learning Curves (Linear Regression vs Random Forest)
# --------------------------------------------------------------------------------------
def plot_learning_curves(X_train, y_train):
    print_header("8. LEARNING CURVES & SAMPLE SIZE SCALING")
    
    from sklearn.model_selection import learning_curve
    
    train_sizes = np.linspace(0.2, 1.0, 5)
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    
    lr_pipe = make_pipeline(StandardScaler(), LinearRegression())
    ts_lr, tr_lr, val_lr = learning_curve(lr_pipe, X_train, y_train, train_sizes=train_sizes, cv=kf, scoring="r2")
    
    rf = RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE)
    ts_rf, tr_rf, val_rf = learning_curve(rf, X_train, y_train, train_sizes=train_sizes, cv=kf, scoring="r2")
    
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(ts_lr, tr_lr.mean(axis=1), "o--", color="#1f78b4", label="Multiple LR train")
    ax.plot(ts_lr, val_lr.mean(axis=1), "o-", color="#1f78b4", label="Multiple LR validation")
    ax.plot(ts_rf, tr_rf.mean(axis=1), "s--", color="#d95f02", label="Random Forest train")
    ax.plot(ts_rf, val_rf.mean(axis=1), "s-", color="#d95f02", label="Random Forest validation")
    ax.set_xlabel("Training examples")
    ax.set_ylabel("R²")
    ax.set_title("Learning curves")
    ax.legend()
    ax.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig16_learning_curves.png"), dpi=300)
    plt.close()


# --------------------------------------------------------------------------------------
# 9. Repeated Cross-Validation & Bootstrap Uncertainty
# --------------------------------------------------------------------------------------
def repeated_cv_and_bootstrap(X, y, X_test, y_test, lasso_cv):
    print_header("9. REPEATED CROSS-VALIDATION & BOOTSTRAP TEST UNCERTAINTY")
    
    def scaled(*steps): return make_pipeline(StandardScaler(), *steps)
    
    rkf = RepeatedKFold(n_splits=5, n_repeats=5, random_state=1)
    models = [
        ("Multiple LR", scaled(LinearRegression())),
        ("Ridge CV-alpha", scaled(Ridge(alpha=41.8))),
        ("Lasso CV-alpha", scaled(Lasso(alpha=1.75))),
        ("Random Forest", RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE)),
        ("Gradient Boosting (tuned)", GradientBoostingRegressor(n_estimators=200, learning_rate=0.1, max_depth=1, random_state=RANDOM_STATE))
    ]
    
    rcv_rows = []
    for name, m in models:
        s = cross_val_score(m, X, y, cv=rkf, scoring="r2")
        rcv_rows.append({
            "Model": name,
            "Mean R2": round(s.mean(), 3),
            "Std of R2": round(s.std(), 3)
        })
        
    print_subheader("Table 15: Repeated 5x5 Cross-Validation on Full Data (442 Patients)")
    print(pd.DataFrame(rcv_rows).to_string(index=False))
    
    # Bootstrap 95% Confidence Interval for Test R2 of Lasso Model
    pred_test = lasso_cv.predict(X_test)
    n_resamples = 2000
    boot_r2s = []
    n_test = len(y_test)
    
    for _ in range(n_resamples):
        indices = np.random.choice(n_test, size=n_test, replace=True)
        boot_r2s.append(r2_score(y_test.iloc[indices], pred_test[indices]))
        
    ci_low, ci_high = np.percentile(boot_r2s, [2.5, 97.5])
    print_subheader("Section 16.4: Test Score Uncertainty (Bootstrap 2,000 Resamples)")
    print(f"Lasso Test R² Point Estimate: {r2_score(y_test, pred_test):.3f}")
    print(f"95% Confidence Interval     : [{ci_low:.2f}, {ci_high:.2f}]")


# --------------------------------------------------------------------------------------
# 10. Residual Diagnostics & Error Analysis
# --------------------------------------------------------------------------------------
def analyze_residuals(y_test, pred_test):
    print_header("10. ERROR & RESIDUAL ANALYSIS (FINAL LASSO MODEL)")
    
    residuals = y_test.values - pred_test
    mean_res = np.mean(residuals)
    std_res = np.std(residuals, ddof=1)
    max_err = np.max(np.abs(residuals))
    within_25 = np.mean(np.abs(residuals) <= 25) * 100
    within_50 = np.mean(np.abs(residuals) <= 50) * 100
    stat_shapiro, p_shapiro = stats.shapiro(residuals)
    
    res_summary = pd.DataFrame([
        {"Quantity": "Mean residual (bias)", "Value": f"{mean_res:.2f}"},
        {"Quantity": "Standard deviation of residuals", "Value": f"{std_res:.2f}"},
        {"Quantity": "Largest absolute error", "Value": f"{max_err:.1f}"},
        {"Quantity": "Predictions within ±25 units", "Value": f"{within_25:.0f}%"},
        {"Quantity": "Predictions within ±50 units", "Value": f"{within_50:.0f}%"},
        {"Quantity": "Shapiro–Wilk normality test, p-value", "Value": f"{p_shapiro:.2f}"}
    ])
    print_subheader("Table 16: Summary of Test-Set Residuals of the Final Model")
    print(res_summary.to_string(index=False))
    
    # Figure 17: Predicted vs Actual, Residuals vs Predicted, Q-Q Plot
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(13, 4))
    
    # 1. Predicted vs Actual
    ax1.scatter(y_test, pred_test, color="#1f78b4", alpha=0.7, s=20)
    ax1.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], "--", color="#ff7f00", linewidth=1.5)
    ax1.set_xlabel("Actual")
    ax1.set_ylabel("Predicted")
    ax1.set_title("Predicted vs actual")
    
    # 2. Residuals vs Predicted
    ax2.scatter(pred_test, residuals, color="#1f78b4", alpha=0.7, s=20)
    ax2.axhline(0, linestyle="--", color="#ff7f00", linewidth=1.5)
    ax2.set_xlabel("Predicted")
    ax2.set_ylabel("Residual")
    ax2.set_title("Residuals vs predicted")
    
    # 3. Normal Q-Q Plot
    stats.probplot(residuals, dist="norm", plot=ax3)
    ax3.set_title("Q–Q plot of residuals")
    ax3.get_lines()[0].set_color("#1f78b4")
    ax3.get_lines()[1].set_color("#ff7f00")
    
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig17_residual_analysis.png"), dpi=300)
    plt.close()


# --------------------------------------------------------------------------------------
# 11. Batch Gradient Descent from Scratch
# --------------------------------------------------------------------------------------
def implement_gradient_descent(X_train, y_train):
    print_header("11. FROM-SCRATCH BATCH GRADIENT DESCENT IMPLEMENTATION")
    
    scaler = StandardScaler().fit(X_train)
    Xs = scaler.transform(X_train)
    Xb = np.c_[np.ones(len(Xs)), Xs]  # Add intercept column of ones
    y_vals = y_train.values
    n = len(y_vals)
    
    # 1. Gradient Descent with lr = 0.1
    w = np.zeros(Xb.shape[1])
    lr = 0.1
    history_mse = []
    
    target_iters = [1, 5, 10, 25, 50, 100, 200, 300]
    iter_records = []
    
    for i in range(300):
        gradient = (2.0 / n) * Xb.T @ (Xb @ w - y_vals)
        w -= lr * gradient
        mse = np.mean((Xb @ w - y_vals) ** 2)
        history_mse.append(mse)
        
        if (i + 1) in target_iters:
            iter_records.append({"Iteration": i + 1, "Training MSE": round(mse, 1)})
            
    print_subheader("Table 17: Training MSE During Gradient Descent (learning rate 0.1)")
    print(pd.DataFrame(iter_records).to_string(index=False))
    
    # Compare with closed-form solution
    ols = LinearRegression().fit(Xs, y_train)
    ols_mse = mean_squared_error(y_train, ols.predict(Xs))
    print(f"\nClosed-form OLS Training MSE: {ols_mse:.1f}")
    print(f"Gradient Descent MSE after 300 iters: {history_mse[-1]:.1f}")
    print(f"OLS Intercept: {ols.intercept_:.2f} | GD Intercept: {w[0]:.2f}")
    
    # 2. Effect of Learning Rates (Table 18)
    learning_rates = [0.001, 0.01, 0.05, 0.1, 0.3]
    lr_rows = []
    lr_trajectories = {}
    
    for l_rate in learning_rates:
        w_curr = np.zeros(Xb.shape[1])
        mses_curr = []
        diverged = False
        
        for i in range(300):
            grad = (2.0 / n) * Xb.T @ (Xb @ w_curr - y_vals)
            w_curr -= l_rate * grad
            curr_mse = np.mean((Xb @ w_curr - y_vals) ** 2)
            if np.isnan(curr_mse) or curr_mse > 1e7:
                diverged = True
                curr_mse = np.nan
            mses_curr.append(curr_mse)
            
        lr_trajectories[l_rate] = mses_curr
        
        if diverged or np.isnan(mses_curr[-1]):
            lr_rows.append({
                "Learning rate": l_rate,
                "After 10": "diverges",
                "After 100": "diverges",
                "After 300": "diverges",
                "Behaviour": "Too large: unstable"
            })
        else:
            beh = "Too slow" if l_rate == 0.001 else ("Converging" if l_rate in [0.01, 0.05] else "Best of those tested")
            lr_rows.append({
                "Learning rate": l_rate,
                "After 10": round(mses_curr[9], 1),
                "After 100": round(mses_curr[99], 1),
                "After 300": round(mses_curr[299], 1),
                "Behaviour": beh
            })
            
    print_subheader("Table 18: Training MSE after 10, 100 and 300 Iterations for Different Learning Rates")
    print(pd.DataFrame(lr_rows).to_string(index=False))
    
    # Figure 18: Convergence and Learning Rate Comparison
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    
    # Left: Convergence curve for lr = 0.1
    ax1.plot(range(1, 301), history_mse, color="#2166ac", label="GD MSE")
    ax1.axhline(ols_mse, color="#d95f02", linestyle="--", label=f"Closed-form MSE ({ols_mse:.1f})")
    ax1.set_xlabel("Iteration")
    ax1.set_ylabel("Training MSE")
    ax1.set_title("Gradient descent, lr = 0.1")
    ax1.legend()
    ax1.grid(True, linestyle="--", alpha=0.5)
    
    # Right: Learning Rate Comparison
    for l_rate in [0.001, 0.01, 0.1, 0.3]:
        traj = np.array(lr_trajectories[l_rate])
        # Mask NaNs for plotting
        valid_idx = np.where(~np.isnan(traj) & (traj < 1e9))[0]
        if len(valid_idx) > 0:
            ax2.plot(valid_idx + 1, traj[valid_idx], label=f"lr={l_rate}")
    ax2.set_yscale("log")
    ax2.set_xlabel("Iteration")
    ax2.set_ylabel("Training MSE (log scale)")
    ax2.set_title("Effect of learning rate")
    ax2.legend()
    ax2.grid(True, linestyle="--", alpha=0.5)
    
    plt.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig18_gradient_descent_convergence.png"), dpi=300)
    plt.close()


# --------------------------------------------------------------------------------------
# 12. Main Execution Pipeline
# --------------------------------------------------------------------------------------
def main():
    print("=" * 80)
    print("  PREDICTING DIABETES DISEASE PROGRESSION USING REGRESSION TECHNIQUES")
    print("  Machine Learning Course Project (25CSA201) | MNR University")
    print("=" * 80)
    
    # 1. Load and explore
    X, y = load_and_explore_data()
    
    # 2. Split and check VIF
    X_train, X_test, y_train, y_test = split_data_and_check_vif(X, y)
    
    # 3. Evaluate course models
    results_df = evaluate_course_models(X_train, X_test, y_train, y_test)
    
    # Generate conceptual figures (Fig 8 & Fig 9)
    generate_conceptual_figures()
    
    # 4. Overfitting study
    poly_df = analyze_polynomial_degrees(X_train, X_test, y_train, y_test)
    
    # 5. Regularization tuning
    best_ridge_a, best_lasso_a, lasso_cv = tune_regularization_and_compare_coefficients(
        X_train, X_test, y_train, y_test
    )
    
    # 6. Ensemble tuning
    tune_ensembles_and_compare(X_train, X_test, y_train, y_test, best_lasso_a)
    
    # 7. Feature importance
    analyze_feature_importance(X_train, X_test, y_train, y_test, lasso_cv)
    
    # 8. Learning curves
    plot_learning_curves(X_train, y_train)
    
    # 9. Repeated CV and bootstrap
    repeated_cv_and_bootstrap(X, y, X_test, y_test, lasso_cv)
    
    # 10. Residual diagnostics
    pred_test = lasso_cv.predict(X_test)
    analyze_residuals(y_test, pred_test)
    
    # 11. Gradient descent from scratch
    implement_gradient_descent(X_train, y_train)
    
    print_header("EXECUTION COMPLETE - ALL 18 FIGURES AND TABLES GENERATED SUCCESSFULLY")
    print(f"Generated visual figures are saved in: {FIG_DIR}")
    print("=" * 80)

if __name__ == "__main__":
    main()
