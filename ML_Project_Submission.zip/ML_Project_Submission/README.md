# Predicting Diabetes Disease Progression Using Regression Techniques

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Library-Scikit--Learn-orange.svg)](https://scikit-learn.org/)
[![Status](https://img.shields.io/badge/Project-Complete%20%26%20Verified-brightgreen.svg)]()
[![Institution](https://img.shields.io/badge/University-MNR%20University-red.svg)]()

> **A Comparative Study of Linear, Polynomial, Regularized, Ensemble, and Gradient Descent Models on a Real Clinical Dataset**  
> **Course Code:** 25CSA201 — Machine Learning Laboratory  
> **Department:** Department of Computer Science and Engineering, School of Engineering, Technology & Artificial Intelligence  
> **Institution:** MNR University, Academic Year 2026–2027 (Year II / Sem I)

---

## 👥 Project Team & Mentorship

| Student Name | Roll Number | Academic Program | Specialization |
| :--- | :--- | :--- | :--- |
| **Syed Sajid** | `25RBCSE0001` | B.Tech (Hons.) | Computer Science & Engineering (CSE) |
| **Pilla Praneeth Sai** | `25RBAID0015` | B.Tech (Hons.) | Artificial Intelligence & Data Science (AI&DS) |
| **Md. Jaffar Pasha** | `25RBAID0025` | B.Tech (Hons.) | Artificial Intelligence & Data Science (AI&DS) |
| **Nevuluri Manoj Kumar** | `25RBAIM0083` | B.Tech (Hons.) | Artificial Intelligence & Machine Learning (AI&ML) |

* **Project Guide:** **Dr. M Praveen Sir** – Assistant Professor, Department of Computer Science and Engineering, MNR University.

---

## 📌 Executive Summary & Abstract

Diabetes mellitus is a chronic condition characterized by impaired glucose regulation. While clinical baselines often appear deceptively similar across patients, subsequent 1-year disease progression diverges sharply. This project builds and evaluates quantitative regression models predicting a **continuous quantitative disease progression score** one year after baseline using ten physiological measurements.

Seven primary regression models from the Machine Learning curriculum were evaluated:
1. **Simple Linear Regression** (BMI only)
2. **Multiple Linear Regression** (Ordinary Least Squares)
3. **Polynomial Regression** (Degrees 2 and 3)
4. **Polynomial Regression (Degree 2) with Ridge Regularization**
5. **Ridge Regression** (L2 regularization, baseline $\alpha=10$ and tuned via `RidgeCV`)
6. **Lasso Regression** (L1 regularization, baseline $\alpha=1$ and tuned via `LassoCV`)
7. **Random Forest Regression** (Default 100 trees and GridSearch tuned)

In addition, **Elastic Net** and **Gradient Boosting Regressors** were evaluated as advanced extensions, and **Vectorized Batch Gradient Descent** was implemented from scratch to study first-principles optimization, loss curvature, and learning rate sensitivity.

### 🔑 Key Academic & Empirical Findings
* **Severe Overfitting Demonstrated:** Polynomial regression of degree 3 produced a catastrophic generalization failure: training $R^2 = 0.877$, but test $R^2 = -14.28$ (worse than predicting the mean).
* **Multicollinearity Resolved:** Serum blood measurements exhibit severe multicollinearity (Variance Inflation Factors: $s_1 = 55.3$, $s_2 = 35.8$). Ridge and Lasso stabilized the ill-conditioned normal equation.
* **Automated Feature Selection:** At cross-validated $\alpha \approx 1.75$, Lasso eliminated three unhelpful predictors (`age`, `s2` LDL, and `s4` TCH), producing the cleanest, most interpretable clinical model.
* **Ensembles vs. Linear Models:** Tuned Random Forest ($R^2 = 0.478$) and Gradient Boosting with depth-1 stumps ($R^2 = 0.476$) matched but did not outperform regularized linear models ($R^2 \approx 0.485$). The underlying clinical phenomenon is predominantly additive and linear.
* **From-Scratch Gradient Descent:** Converged to within 0.4% of the closed-form OLS training MSE ($2878.9$ vs $2868.5$) after 300 iterations ($\eta = 0.1$), exactly replicating mathematical theory.

---

## 📂 Deliverables & Submission File Manifest

This workspace contains all required deliverables organized directly in the root directory:

| Filename | Type | Description |
| :--- | :--- | :--- |
| **`diabetes_progression.py`** | Source Code | Complete, self-contained Python program executing all 11 experimental sections, printing all comparison tables, and generating all 16 figures. |
| **`requirements.txt`** | Dependency Config | Pinned package dependencies (`numpy`, `pandas`, `scipy`, `scikit-learn`, `matplotlib`, `python-pptx`, `reportlab`). |
| **`dataset_source.txt`** | Documentation | Complete data acquisition guide, provenance, attribute units, and Python loading instructions. |
| **`Project_Report.pdf`** | College Report | 18-page formal academic report complete with cover page, certificate, declaration, abstract, mathematical derivations, tables, and embedded high-resolution figures. |
| **`Project_Presentation.pptx`**| Presentation | 12-slide professional widescreen (16:9) presentation deck tailored for college viva and project evaluations. |
| **`Demo_Video_Link.txt`** | Submission Link | Video demonstration placeholder containing timestamps, script outline, and grading rubric checklist. |
| **`figures/`** | Visual Artifacts | Directory containing all 16 high-resolution publication-quality PNG charts (`fig03` through `fig18`). |
| **`README.md`** | GitHub Landing | Comprehensive project documentation and execution guide. |

---

## 📊 Dataset Description & Clinical Attributes

The study utilizes the benchmark clinical diabetes dataset introduced by Bradley Efron, Trevor Hastie, Iain Johnstone, and Robert Tibshirani (2004) in *"Least Angle Regression"*:

* **Cohort Size:** 442 patients
* **Input Features:** 10 numerical physiological baseline measurements
* **Missing Values:** 0 (fully complete dataset)
* **Target Variable:** Quantitative disease progression score one year after baseline ($y \in [25, 346]$, $\mu = 152.13$, $\sigma = 77.09$, skewness = $0.44$).
* **Access Mode:** Loaded with `load_diabetes(as_frame=True, scaled=False)` to maintain true physiological units.

| Feature | Description | Physiological Units / Range | Mean ± Std |
| :--- | :--- | :--- | :--- |
| **`age`** | Patient age | 19 to 79 years | $48.52 \pm 13.11$ |
| **`sex`** | Biological sex | Coded: 1 (female, n=235), 2 (male, n=207) | $1.47 \pm 0.50$ |
| **`bmi`** | Body mass index | 18.0 to 42.2 $\text{kg/m}^2$ | $26.38 \pm 4.42$ |
| **`bp`** | Mean arterial blood pressure | 62.0 to 133.0 mmHg | $94.65 \pm 13.83$ |
| **`s1`** | Total serum cholesterol (TC) | 97.0 to 301.0 mg/dL | $189.14 \pm 34.61$ |
| **`s2`** | Low-density lipoproteins (LDL) | 41.6 to 242.4 mg/dL | $115.44 \pm 30.41$ |
| **`s3`** | High-density lipoproteins (HDL) | 22.0 to 99.0 mg/dL | $49.79 \pm 12.93$ |
| **`s4`** | Total cholesterol / HDL ratio | 2.00 to 9.09 | $4.07 \pm 1.29$ |
| **`s5`** | Log serum triglycerides (LTG) | 3.26 to 6.11 | $4.64 \pm 0.52$ |
| **`s6`** | Fasting blood glucose level | 58.0 to 124.0 mg/dL | $91.26 \pm 11.50$ |

---

## ⚙️ Methodology & Pipeline Architecture

```
   Raw Clinical Data (442 Patients, 10 Features)
                       │
                       ▼
       Exploratory Data Analysis & VIF Diagnostics
                       │
                       ▼
          80:20 Train/Test Split (seed = 42)
        ├── Training Set (353 samples)
        └── Test Set (89 samples, held out)
                       │
                       ▼
     Feature Scaling (StandardScaler inside Pipeline)
   [Prevents Data Leakage: Scaler fitted ONLY on train folds]
                       │
                       ▼
               Model Exploration
    ├── Simple & Multiple Linear Regression
    ├── Polynomial Regression (Degrees 1 to 4)
    ├── L2 Regularization (Ridge & RidgeCV)
    ├── L1 Regularization (Lasso & LassoCV)
    ├── Elastic Net (L1 + L2)
    ├── Tree Ensembles (Random Forest & Gradient Boosting)
    └── Vectorized Batch Gradient Descent from Scratch
                       │
                       ▼
          Cross-Validation & Error Analysis
    ├── 5-Fold Cross-Validation on Training Set
    ├── Repeated 5×5 Cross-Validation on Full Data
    ├── Bootstrap 95% Confidence Interval (2,000 resamples)
    └── Residual Diagnostics (Shapiro-Wilk Normality test)
```

---

## 📈 Experimental Results & Benchmark Comparisons

All metrics were generated by executing `diabetes_progression.py` using `random_state=42` and strictly matching the submitted college report.

### 1. Performance of the Course Regression Models (Table 9)
*Evaluated on the held-out test set of 89 patients; 5-fold CV on training set.*

| Model | Train $R^2$ | Test MAE | Test MSE | Test RMSE | Test $R^2$ | 5-Fold CV $R^2$ (mean ± std) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Simple LR (BMI only)** | 0.3657 | 52.26 | 4061.83 | 63.73 | 0.2334 | $0.3355 \pm 0.0751$ |
| **Multiple LR** | 0.5279 | 42.79 | 2900.19 | 53.85 | 0.4526 | $0.4804 \pm 0.0409$ |
| **Polynomial (deg 2) LR** | 0.6062 | 43.58 | 3096.03 | 55.64 | 0.4156 | $0.3388 \pm 0.0701$ |
| **Polynomial (deg 3) LR** | 0.8766 | 162.32 | 80980.76 | 284.57 | **-14.2847** | **-523.2569 ± 622.1784** |
| **Polynomial (deg 2) + Ridge** | 0.5610 | 41.47 | 2649.61 | 51.47 | **0.4999** | $0.4509 \pm 0.0540$ |
| **Ridge ($\alpha=10$)** | 0.5248 | 42.86 | 2875.78 | 53.63 | 0.4572 | $0.4797 \pm 0.0389$ |
| **Lasso ($\alpha=1$)** | 0.5225 | 42.80 | 2824.57 | 53.15 | 0.4669 | $0.4808 \pm 0.0365$ |
| **Random Forest (100 trees)** | 0.9239 | 44.08 | 2953.62 | 54.35 | 0.4425 | $0.3983 \pm 0.0710$ |

---

### 2. Polynomial Complexity & Catastrophic Overfitting (Table 10)

| Degree | Generated Features | Train $R^2$ | Test $R^2$ | Diagnosis |
| :---: | :---: | :---: | :---: | :--- |
| **1** | 10 | 0.528 | 0.453 | Good fit, small generalization gap |
| **2** | 65 | 0.606 | 0.416 | Training rises, test falls: mild overfitting |
| **3** | 285 | 0.877 | **-14.285** | Severe overfitting (model memorizes noise) |
| **4** | 1000 | 1.000 | **-26.648** | Complete memorization, total generalization collapse |

---

### 3. Regularization & Coefficient Shrinkage (Table 11)
*Feature coefficients evaluated on standardized training features.*

| Feature | Linear (OLS) | Ridge ($\alpha=10$) | Lasso ($\alpha=1$) | RidgeCV ($\alpha \approx 41.8$) | LassoCV ($\alpha \approx 1.75$) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **`age`** | +1.75 | +1.93 | +0.69 | +2.01 | **0.00** *(Eliminated)* |
| **`sex`** | -11.51 | -11.03 | -9.30 | -9.85 | -7.82 |
| **`bmi`** | **+25.61** | **+25.61** | **+26.22** | **+24.04** | **+26.17** |
| **`bp`** | +16.83 | +16.30 | +15.66 | +15.33 | +14.96 |
| **`s1`** | **-44.45** | -12.93 | -8.23 | -5.27 | -4.60 |
| **`s2`** | **+24.64** | +0.54 | **0.00** | -4.09 | **0.00** *(Eliminated)* |
| **`s3`** | +7.68 | -6.13 | -9.02 | -8.98 | -11.02 |
| **`s4`** | +13.14 | +8.57 | +3.42 | +7.21 | **0.00** *(Eliminated)* |
| **`s5`** | **+35.16** | **+22.75** | **+22.64** | **+18.83** | **+21.83** |
| **`s6`** | +2.35 | +2.92 | +2.10 | +3.80 | +1.66 |

> **Observation:** OLS assigns huge opposite weights to `s1` (-44.45) and `s2` (+24.64) due to collinearity ($r = 0.897$). LassoCV successfully sets `age`, `s2`, and `s4` strictly to **0.00**, delivering a clean 7-feature clinical model while preserving top accuracy ($R^2 = 0.472$, $\text{RMSE} = 52.91$).

---

### 4. Tuned Ensembles vs. Linear Models (Table 14)

| Model | Train $R^2$ | Test MAE | Test RMSE | Test $R^2$ | 5-Fold CV $R^2$ |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Lasso (CV $\alpha \approx 1.75$)** | 0.519 | 42.81 | 52.91 | 0.472 | 0.479 |
| **Random Forest (default 100)** | 0.924 | 44.08 | 54.35 | 0.443 | 0.398 |
| **Random Forest (tuned: 300 trees, depth 8, leaf 10)**| 0.653 | 42.43 | 52.60 | 0.478 | 0.432 |
| **Gradient Boosting (default depth 2)** | 0.723 | 43.05 | 53.18 | 0.466 | 0.421 |
| **Gradient Boosting (tuned depth 1 stumps)** | 0.629 | 41.62 | 52.67 | 0.476 | 0.449 |
| **Elastic Net (CV: $\alpha \approx 0.119, \rho=0.1$)** | — | 42.98 | 53.46 | 0.460 | 0.477 |

---

### 5. From-Scratch Batch Gradient Descent Convergence (Table 17 & 18)
*Vectorized update:* $w \leftarrow w - \eta \cdot \frac{2}{n} X_b^T (X_b w - y)$

* **Closed-Form OLS Benchmark Training MSE:** `2868.5` | **Intercept:** `153.74`
* **Gradient Descent Training MSE ($\eta = 0.1$):**
  * Iteration 1: `18908.3`
  * Iteration 5: `5561.9`
  * Iteration 10: `3188.8`
  * Iteration 50: `2894.7`
  * Iteration 300: **`2878.9`** *(within 0.4% of optimum)* | **Learned Intercept:** `153.74`
* **Learning Rate Sensitivity:**
  * $\eta = 0.001$: Too slow (MSE after 300 iters = 10,386.1)
  * $\eta = 0.01$: Converging smoothly (MSE = 2897.0)
  * $\eta = 0.1$: Optimal convergence (MSE = 2878.9)
  * $\eta = 0.3$: **Diverges explosively** (violates theoretical stability bound $\eta < 2/\lambda_{\max} \approx 0.25$)

---

### 6. Error & Residual Diagnostics for Final Lasso Model (Table 16)

* **Mean Residual (Bias):** `2.98` (unbiased, centered near zero)
* **Standard Deviation of Residuals:** `52.83`
* **Maximum Absolute Prediction Error:** `147.9`
* **Predictions within ±25 Units:** `36%`
* **Predictions within ±50 Units:** `65%`
* **Shapiro–Wilk Normality Test:** $p = 0.95$ (residuals conform strictly to a Gaussian distribution)

---

## 💻 Installation & Quickstart Execution

### Step 1: Clone Repository & Open Folder
```bash
git clone https://github.com/your-username/Predicting-Diabetes-Progression-Regression.git
cd Predicting-Diabetes-Progression-Regression
```

### Step 2: Create and Activate Virtual Environment (Optional but Recommended)
```bash
# Windows
python -m venv .venv
.venv\Scripts\activate

# macOS / Linux
python3 -m venv .venv
source .venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Complete Machine Learning Project
```bash
python diabetes_progression.py
```
*This command executes the entire pipeline end-to-end, displays all comparison tables in the console, and regenerates all 16 figures in `./figures/`.*

---

## 🖼️ Index of Generated Figures

All plots are rendered and saved at 300 DPI:

* `figures/fig03_target_distribution.png`: Histogram and boxplot of disease progression target.
* `figures/fig04_feature_histograms.png`: Distribution of all ten baseline physiological features.
* `figures/fig05_feature_scatter_fitted_lines.png`: Scatter plots with fitted linear regression lines.
* `figures/fig06_correlation_matrix.png`: Full Pearson correlation matrix heatmap.
* `figures/fig07_simple_lr_bmi.png`: Simple Linear Regression line on BMI ($y = -131.87 + 10.76 \cdot \text{BMI}$).
* `figures/fig08_l1_vs_l2_constraint.png`: Geometric explanation of L1 (diamond corner contact) vs L2 (circular).
* `figures/fig09_polynomial_tradeoff.png`: Synthetic curves illustrating underfitting, good fit, and overfitting.
* `figures/fig10_model_comparison_r2.png`: Bar chart comparing Train, 5-Fold CV, and Test $R^2$.
* `figures/fig11_polynomial_degree_overfitting.png`: Train vs test score collapse across polynomial degrees 1–4.
* `figures/fig12_coefficients_comparison.png`: Coefficient comparison bar chart (Linear vs Ridge vs Lasso).
* `figures/fig13_regularization_paths.png`: Coefficient trace paths for Ridge and Lasso across $\log(\alpha)$.
* `figures/fig14_cv_mse_vs_alpha.png`: 5-fold cross-validated MSE tuning curves for RidgeCV and LassoCV.
* `figures/fig15_feature_importance.png`: Side-by-side Random Forest MDI and Lasso Permutation Importance.
* `figures/fig16_learning_curves.png`: Sample size scaling curves for Multiple LR and Random Forest.
* `figures/fig17_residual_analysis.png`: Predicted vs Actual, Residuals vs Fitted, and Normal Q-Q plot.
* `figures/fig18_gradient_descent_convergence.png`: First-principles gradient descent loss trajectory.

---

## 🏥 Clinical Ethics, Fairness & Limitations

1. **Academic Decision-Support Tool:** The models explain approximately 48% to 50% of progression variance ($R^2 \approx 0.48$). Over half of disease progression is governed by variables absent from this benchmark (lifestyle, dietary habits, genetics, pharmaceutical adherence). These models must **never** be used for autonomous diagnosis or drug dosage changes.
2. **Transparent vs. Black-Box Models:** In clinical settings, transparent models whose coefficients can be validated against physiology (such as regularized linear models) are vastly preferred over black-box ensembles that provide zero performance advantage on this data.
3. **Cohort Representation:** The dataset originates from a single study cohort; validation across diverse hospitals and international demographics is essential before generalizing.

---

## 📜 Academic Attribution & References

1. **Efron, B., Hastie, T., Johnstone, I., & Tibshirani, R. (2004).** Least Angle Regression. *Annals of Statistics*, 32(2), 407–499.
2. **Hoerl, A. E., & Kennard, R. W. (1970).** Ridge Regression: Biased Estimation for Nonorthogonal Problems. *Technometrics*, 12(1), 55–67.
3. **Tibshirani, R. (1996).** Regression Shrinkage and Selection via the Lasso. *Journal of the Royal Statistical Society, Series B*, 58(1), 267–288.
4. **Zou, H., & Hastie, T. (2005).** Regularization and Variable Selection via the Elastic Net. *Journal of the Royal Statistical Society, Series B*, 67(2), 301–320.
5. **Breiman, L. (2001).** Random Forests. *Machine Learning*, 45(1), 5–32.
6. **Friedman, J. H. (2001).** Greedy Function Approximation: A Gradient Boosting Machine. *Annals of Statistics*, 29(5), 1189–1232.
7. **Pedregosa, F., et al. (2011).** Scikit-learn: Machine Learning in Python. *Journal of Machine Learning Research*, 12, 2825–2830.

---
*Submitted in partial fulfillment of the requirements for the Machine Learning Laboratory (25CSA201) course at MNR University, AY 2026–2027.*
